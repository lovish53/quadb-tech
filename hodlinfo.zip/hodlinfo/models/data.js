const mongoose=require('mongoose')

const dataSchema=mongoose.Schema({
    name:String,
    last:Number,
    Buy:Number,
    Sell:Number,
    volume:Number,
    base_unit:String,
    Highestprice:Number
})

module.exports=mongoose.model('data',dataSchema)