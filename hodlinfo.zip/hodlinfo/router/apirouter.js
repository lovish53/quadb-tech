
const router=require("express").Router()
const datac=require('../controllers/datacontroller')


router.get('/', datac.datapage)
router.get('/adddata',datac.adddata)


module.exports=router;