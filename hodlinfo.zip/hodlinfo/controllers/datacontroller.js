const Data=require('../models/data')
const fetch=require('node-fetch')


exports.adddata=async (req,res)=>{
  const response= await fetch('https://api.wazirx.com/api/v2/tickers')
  const result= await response.json()
  const arr=Object.values(result) 
  const top10=arr.slice(0,10)
  for(i=0;i<10;i++){
    const record= new Data({name:top10[i].name,last:top10[i].last,Buy:top10[i].buy,Sell:top10[i].sell,volume:top10[i].volume,base_unit:top10[i].base_unit,Highestprice:top10[i].high}) 
    record.save()
  }
  
 
  
}

exports.datapage=async(req,res)=>{
  const saving=req.session.Saving
  const rec= await Data.find()
  const data=await Data.findOne()
  res.render('index.ejs',{rec,data,saving})
}