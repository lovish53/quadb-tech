const express=require('express')
const app= express()
const apiRouter=require('./router/apirouter')
const session=require('express-session')
app.use(express.urlencoded({extended:false}))
const mongoose=require('mongoose')

require('dotenv').config();
mongoose.connect(`${process.env.DB_LINK}/${process.env.DB_NAME}`);
app.use(session({
    secret:'lovish',
    resave:false,
    saveUninitialized:false,
}))
app.use(apiRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(process.env.PORT,()=>{console.log('server is running on port 5000')});